package dominio;

/**
 * Clase abstracta base para todas las entidades con ID.
 * Demuestra herencia y abstracción.
 */
public abstract class EntidadBase {
    private String id;

    public EntidadBase(String id) {
        this.id = id;
    }
    public String getId() {
        return id;
    }
    public abstract String descripcion();
}

