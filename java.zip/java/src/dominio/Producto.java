package dominio;

/**
 * Representa un producto en inventario.
 */
public class Producto extends EntidadBase {
    private String nombre;
    private double precioUnitario;
    private double tasaImpuesto;
    private int stock;
    private boolean inventariable;

    public Producto(String id, String nombre, double precioUnitario, double tasaImpuesto, int stock, boolean inventariable) {
        super(id);
        this.nombre = nombre;
        this.precioUnitario = precioUnitario;
        this.tasaImpuesto = tasaImpuesto;
        this.stock = stock;
        this.inventariable = inventariable;
    }

    public String getNombre() { return nombre; }
    public double getPrecioUnitario() { return precioUnitario; }
    public double getTasaImpuesto() { return tasaImpuesto; }
    public int getStock() { return stock; }
    public boolean isInventariable() { return inventariable; }

    public void ajustarStock(int cantidad) { this.stock += cantidad; }
    public boolean tieneStock(int cantidad) { return !inventariable || stock >= cantidad; }

    // Sobrecarga de método para mostrar info corta o larga
    public String descripcion() { return nombre; }
    public String descripcion(boolean detalle) {
        if (detalle) {
            return nombre + " | Precio: " + precioUnitario + " | Stock: " + stock;
        }
        return nombre;
    }

    /*@Override
    public String descripcion() {
        return descripcion(true); // sobrescritura con detalle
    }*/
}

