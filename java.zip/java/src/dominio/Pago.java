package dominio;

public class Pago {
    private String id;
    private double monto;
    private MedioPago medio;
    private String referencia;

    public Pago(String id, double monto, MedioPago medio, String referencia) {
        this.id = id;
        this.monto = monto;
        this.medio = medio;
        this.referencia = referencia;
    }

    public String getId() { return id; }
    public double getMonto() { return monto; }
    public MedioPago getMedio() { return medio; }
    public String getReferencia() { return referencia; }
}
