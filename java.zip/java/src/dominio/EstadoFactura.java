package dominio;

public enum EstadoFactura { EMITIDA, ANULADA }
