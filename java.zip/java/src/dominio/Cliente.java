package dominio;

/**
 * Representa un cliente del sistema.
 * Demuestra herencia, encapsulamiento y polimorfismo.
 */
public class Cliente extends EntidadBase {
    private String nombre;
    private String identificacion;
    private String email;
    private String telefono;

    public Cliente(String id, String nombre, String identificacion, String email, String telefono) {
        super(id);
        this.nombre = nombre;
        this.identificacion = identificacion;
        this.email = email;
        this.telefono = telefono;
    }

    public String getNombre() { return nombre; }
    public String getIdentificacion() { return identificacion; }
    public String getEmail() { return email; }
    public String getTelefono() { return telefono; }

    public void setNombre(String nombre) { this.nombre = nombre; }
    public void setEmail(String email) { this.email = email; }
    public void setTelefono(String telefono) { this.telefono = telefono; }

    public String descripcion() {
        return "Cliente: " + nombre + " (" + getId() + ")";
    }

    private String getId() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}

