package dominio;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;

/**
 * Factura de venta de productos.
 */
public class Factura extends EntidadBase {
    private LocalDateTime fechaHora;
    private Cliente cliente;
    private List<ItemFactura> items = new ArrayList<>();
    private List<Pago> pagos = new ArrayList<>();

    private double subtotal;
    private double totalImpuestos;
    private double totalDescuentos;
    private double total;
    private EstadoFactura estado = EstadoFactura.EMITIDA;

    public Factura(String numero, Cliente cliente) {
        super(numero);
        this.cliente = cliente;
        this.fechaHora = LocalDateTime.now();
    }

    // Sobrecarga: agregar item con o sin descuento
    public void agregarItem(Producto p, int cant) { agregarItem(p, cant, 0); }

    public void agregarItem(Producto p, int cant, double desc) {
        items.add(new ItemFactura(p, cant, p.getPrecioUnitario(), desc));
    }

    public void registrarPago(Pago pago) { pagos.add(pago); }

    public void calcularTotales() {
        subtotal = items.stream().mapToDouble(i -> i.getPrecioUnitario() * i.getCantidad()).sum();
        totalDescuentos = items.stream().mapToDouble(ItemFactura::getDescuento).sum();
        totalImpuestos = items.stream().mapToDouble(ItemFactura::impuesto).sum();
        total = items.stream().mapToDouble(ItemFactura::totalLinea).sum();
    }

    public void cerrar() { calcularTotales(); }

    public LocalDateTime getFechaHora() { return fechaHora; }
    public Cliente getCliente() { return cliente; }
    public List<ItemFactura> getItems() { return items; }
    public List<Pago> getPagos() { return pagos; }
    public double getSubtotal() { return subtotal; }
    public double getTotalImpuestos() { return totalImpuestos; }
    public double getTotalDescuentos() { return totalDescuentos; }
    public double getTotal() { return total; }
    public EstadoFactura getEstado() { return estado; }
    public void setEstado(EstadoFactura e) { this.estado = e; }

    public Instant getFecha() { return fechaHora.atZone(ZoneId.systemDefault()).toInstant(); }

    public String descripcion() {
        return "Factura " + getId() + " | Cliente: " + (cliente != null ? cliente.getNombre() : "Consumidor final") +
                " | Total: " + total;
    }

    private String getId() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}


