public abstract class EntidadBase {
    private String id;

    public EntidadBase(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    /**
     * Método abstracto que debe implementarse para mostrar info de la entidad.
     * Demuestra polimorfismo.
     */
    public abstract String descripcion();
}
