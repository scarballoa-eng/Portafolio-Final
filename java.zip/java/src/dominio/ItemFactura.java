package dominio;

/**
 * Representa un item dentro de una factura.
 */
public class ItemFactura {
    private Producto producto;
    private int cantidad;
    private double precioUnitario;
    private double descuento;

    public ItemFactura(Producto producto, int cantidad, double precioUnitario, double descuento) {
        this.producto = producto;
        this.cantidad = cantidad;
        this.precioUnitario = precioUnitario;
        this.descuento = descuento;
    }

    public double base() { return (precioUnitario * cantidad) - descuento; }
    public double impuesto() { return producto.getTasaImpuesto() * base(); }
    public double totalLinea() { return base() + impuesto(); }

    public Producto getProducto() { return producto; }
    public int getCantidad() { return cantidad; }
    public double getPrecioUnitario() { return precioUnitario; }
    public double getDescuento() { return descuento; }
}

