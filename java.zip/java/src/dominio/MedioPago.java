package dominio;

public enum MedioPago { EFECTIVO, TARJETA, TRANSFERENCIA }
