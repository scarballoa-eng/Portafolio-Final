package persistencia.memory;

import dominio.Producto;
import persistencia.ProductoRepository;
import java.util.ArrayList;
import java.util.List;

public class ProductoRepositoryImpl implements ProductoRepository {
    private final List<Producto> productos = new ArrayList<>();

    @Override
    public Producto findById(String id) {
        return productos.stream()
                .filter(p -> p.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

    @Override
    public void save(Producto p) {
        productos.add(p);
    }

    @Override
    public void update(Producto p) {
        // simple example: remove and add updated
        productos.removeIf(prod -> prod.getId().equals(p.getId()));
        productos.add(p);
    }

    @Override
    public List<Producto> listAll() {
        return productos;
    }
}

