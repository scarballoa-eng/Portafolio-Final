package persistencia.memory;

import dominio.Cliente;
import persistencia.ClienteRepository;
import java.util.ArrayList;
import java.util.List;

public class ClienteRepositoryImpl implements ClienteRepository {
    private final List<Cliente> clientes = new ArrayList<>();

    @Override
    public Cliente findById(String id) {
        return clientes.stream()
                .filter(c -> c.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

    @Override
    public void save(Cliente c) {
        clientes.add(c);
    }
}

