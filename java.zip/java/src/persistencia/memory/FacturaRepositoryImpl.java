package persistencia.memory;

import dominio.Factura;
import persistencia.FacturaRepository;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class FacturaRepositoryImpl implements FacturaRepository {
    private final List<Factura> facturas = new ArrayList<>();
    private int counter = 1;

    @Override
    public String nextConsecutive() {
        return "F" + (counter++);
    }

    @Override
    public void save(Factura f) {
        facturas.add(f);
    }

    @Override
    public Factura findByNumero(String numero) {
        return facturas.stream()
                .filter(f -> f.getNumero().equals(numero))
                .findFirst()
                .orElse(null);
    }

    @Override
    public List<Factura> listByFecha(LocalDateTime desde, LocalDateTime hasta) {
        // Compare LocalDateTime directly (no Instant conversion)
        return facturas.stream()
                .filter(f -> {
                    LocalDateTime t = f.getFechaHora();
                    if (t == null) return false;
                    boolean afterOrEqFrom = t.isEqual(desde) || t.isAfter(desde);
                    boolean beforeOrEqTo  = t.isEqual(hasta) || t.isBefore(hasta);
                    return afterOrEqFrom && beforeOrEqTo;
                })
                .sorted(Comparator.comparing(Factura::getFechaHora))
                .toList();
    }
}

