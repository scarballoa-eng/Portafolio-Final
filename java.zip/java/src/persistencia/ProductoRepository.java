package persistencia;

import dominio.Producto;
import java.util.List;

public interface ProductoRepository {
    Producto findById(String id);
    void save(Producto p);
    void update(Producto p);
    List<Producto> listAll();
}
