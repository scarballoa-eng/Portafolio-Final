package persistencia;

import dominio.Cliente;

public interface ClienteRepository {
    Cliente findById(String id);
    void save(Cliente c);
}
