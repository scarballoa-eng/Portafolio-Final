package persistencia;

import dominio.Factura;
import java.time.LocalDateTime;
import java.util.List;

public interface FacturaRepository {
    String nextConsecutive();
    void save(Factura f);
    Factura findByNumero(String numero);
    List<Factura> listByFecha(LocalDateTime desde, LocalDateTime hasta);
}
