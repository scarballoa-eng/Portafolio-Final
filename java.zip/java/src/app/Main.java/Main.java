package app.Main.java;

import dominio.*;
import persistencia.ClienteRepository;
import persistencia.FacturaRepository;
import persistencia.ProductoRepository;
import servicio.*;

import java.time.LocalDate;

public class Main {


    private static void title(String t) {
        System.out.println("\n=== " + t + " ===");
    }

    private static void printInvoice(Factura f) {
        System.out.println("-FACTURA");
        System.out.println("Número : " + f.getNumero());
        System.out.println("Cliente: " + (f.getCliente() == null ? "(contado)" : f.getCliente().getNombre()));
        System.out.println("Estado : " + f.getEstado());
        for (ItemFactura it : f.getItems()) {
            System.out.printf("  - %s x%d  (₡%.2f c/u, desc ₡%.2f)  ₡%.2f%n",
                    it.getProducto().getNombre(),
                    it.getCantidad(),
                    it.getPrecioUnitario(),
                    it.getDescuento(),
                    it.totalLinea());
        }
        System.out.printf("Subtotal   : ₡%.2f%n", f.getSubtotal());
        System.out.printf("Impuestos  : ₡%.2f%n", f.getTotalImpuestos());
        System.out.printf("Descuentos : ₡%.2f%n", f.getTotalDescuentos());
        System.out.printf("TOTAL      : ₡%.2f%n", f.getTotal());
        System.out.println("---------------------------------------");
    }

    public static void main(String[] args) {
        System.out.println("App started ✅");


        ProductoRepository prodRepo = new persistencia.memory.ProductoRepositoryImpl();
        ClienteRepository  cliRepo  = new persistencia.memory.ClienteRepositoryImpl();
        FacturaRepository  facRepo  = new persistencia.memory.FacturaRepositoryImpl();

        InventarioService  inventario = new InventarioService(prodRepo);
        IVAEstandar        impuestos  = new IVAEstandar();
        FacturacionService facturas   = new FacturacionService(prodRepo, facRepo, cliRepo, impuestos, inventario);
        ReporteService     reportes   = new ReporteService(facRepo);

        // -------- seed data --------
        prodRepo.save(new Producto("A1","Teclado",         25000, 0.13, 10, true));
        prodRepo.save(new Producto("B7","Mouse",           15000, 0.13, 20, true));
        prodRepo.save(new Producto("C3","Audífonos",       30000, 0.13,  5, true));
        prodRepo.save(new Producto("S1","Soporte técnico", 20000, 0.13,  0, false)); // servicio (no inventariable)

        cliRepo.save(new Cliente("C001","Ana Pérez",   "1-2345-6789","ana@correo.com","8888-8888"));
        cliRepo.save(new Cliente("C002","Carlos Ruiz", "2-1111-2222","carlos@correo.com","7777-7777"));

        // ========= Scenario 1: normal sale with customer =========
        title("casoo 1: venta y multiples items");
        Factura f1 = facturas.iniciarFactura("C001");
        facturas.agregarItem(f1,"A1",2,0);
        facturas.agregarItem(f1,"B7",1,0);
        facturas.registrarPago(f1, MedioPago.EFECTIVO, 60000, "Caja 1");
        f1 = facturas.emitir(f1);
        printInvoice(f1);

        // ========= Scenario 2: cash sale (no customer) with discount =========
        title("Caso 2: Venta con descuento");
        Factura f2 = facturas.iniciarFactura(null);
        facturas.agregarItem(f2,"C3",1,5000); // discount on headphones
        facturas.registrarPago(f2, MedioPago.TARJETA, 25000, "POS-123");
        f2 = facturas.emitir(f2);
        printInvoice(f2);

        // ========= Scenario 3: multiple payments =========
        title("Caso 3: Varios pagos (Tarjeta y efectivo)");
        Factura f3 = facturas.iniciarFactura("C002");
        facturas.agregarItem(f3,"A1",1,0);
        facturas.agregarItem(f3,"B7",2,0);
        facturas.registrarPago(f3, MedioPago.EFECTIVO, 10000, "Caja 2");
        facturas.registrarPago(f3, MedioPago.TARJETA, 60000, "POS-456");
        f3 = facturas.emitir(f3);
        printInvoice(f3);

        // ========= Scenario 4: service item (non-inventoriable) =========
        title("Caso 5: Servicio");
        Factura f4 = facturas.iniciarFactura("C001");
        facturas.agregarItem(f4,"S1",1,0); // service
        facturas.registrarPago(f4, MedioPago.TRANSFERENCIA, 20000, "TRX-001");
        f4 = facturas.emitir(f4);
        printInvoice(f4);

        // ========= Scenario 5: insufficient stock (should throw) =========
        title("Caso 5: No hay en stock");
        Factura f5 = facturas.iniciarFactura("C002");
        facturas.agregarItem(f5,"C3",99,0);  // more than available
        try {
            f5 = facturas.emitir(f5);         // expected to fail
            printInvoice(f5);
        } catch (IllegalStateException ex) {
            System.out.println("No se proceso: " + ex.getMessage());
        }

        // ========= Scenario 6: annul an invoice =========
        title("Caso 6: ");
        facturas.anular(f2.getNumero());
        System.out.println("Invoic " + f2.getNumero() + " Anulado.");

        // ========= Day report =========
        title("Ventas del dia");
        double totalToday = reportes.ventasPorDia(LocalDate.now());
        System.out.printf("Ventas de hoy: ₡%.2f%n", totalToday);

        System.out.println("\nProceso finalizado");
    }
}

