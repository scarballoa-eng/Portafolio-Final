package servicio;

import dominio.Factura;
import persistencia.FacturaRepository;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class ReporteService {
    private final FacturaRepository facturas;

    public ReporteService(FacturaRepository facturas) { this.facturas = facturas; }

    public double ventasPorDia(LocalDate fecha) {
        LocalDateTime desde = fecha.atStartOfDay();
        LocalDateTime hasta = fecha.plusDays(1).atStartOfDay().minusNanos(1);
        return facturas.listByFecha(desde, hasta).stream().mapToDouble(Factura::getTotal).sum();
    }
}
