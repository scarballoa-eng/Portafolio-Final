package servicio;

import dominio.Producto;

public interface PoliticaImpuesto {
    double calcular(Producto producto, int cantidad, double precioUnitario);
}
