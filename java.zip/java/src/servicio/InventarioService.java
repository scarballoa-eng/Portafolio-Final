package servicio;

import dominio.ItemFactura;
import dominio.Producto;
import persistencia.ProductoRepository;
import java.util.List;

public class InventarioService {
    private final ProductoRepository productos;

    public InventarioService(ProductoRepository productos) { this.productos = productos; }

    public void descontar(List<ItemFactura> items) {
        for (ItemFactura it : items) {
            Producto p = it.getProducto();
            if (p.isInventariable() && !p.tieneStock(it.getCantidad())) {
                throw new IllegalStateException("Stock insuficiente: " + p.getNombre());
            }
        }
        for (ItemFactura it : items) {
            Producto p = it.getProducto();
            if (p.isInventariable()) {
                p.ajustarStock(-it.getCantidad());
                productos.update(p);
            }
        }
    }

    public void reponer(List<ItemFactura> items) {
        for (ItemFactura it : items) {
            Producto p = it.getProducto();
            if (p.isInventariable()) {
                p.ajustarStock(it.getCantidad());
                productos.update(p);
            }
        }
    }
}
