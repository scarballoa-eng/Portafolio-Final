package servicio;

import dominio.*;
import java.util.UUID;
import persistencia.ClienteRepository;
import persistencia.FacturaRepository;
import persistencia.ProductoRepository;

/**
 * Servicio principal de facturación, demostrando abstracción y polimorfismo.
 */
public class FacturacionService {
    private final ProductoRepository productos;
    private final FacturaRepository facturas;
    private final ClienteRepository clientes;
    private final PoliticaImpuesto politica;
    private final InventarioService inventario;

    public FacturacionService(ProductoRepository productos,
                              FacturaRepository facturas,
                              ClienteRepository clientes,
                              PoliticaImpuesto politica,
                              InventarioService inventario) {
        this.productos = productos;
        this.facturas = facturas;
        this.clientes = clientes;
        this.politica = politica;
        this.inventario = inventario;
    }

    public Factura iniciarFactura(String clienteId) {
        Cliente c = (clienteId == null) ? null : clientes.findById(clienteId);
        return new Factura(facturas.nextConsecutive(), c);
    }

    // Sobrecarga: agregar item con o sin descuento
    public void agregarItem(Factura f, String prodId, int cant) { agregarItem(f, prodId, cant, 0); }

    public void agregarItem(Factura f, String prodId, int cant, double desc) {
        Producto p = productos.findById(prodId);
        if (p == null) throw new IllegalArgumentException("Producto no existe: " + prodId);
        politica.calcular(p, cant, p.getPrecioUnitario()); // abstracción
        f.agregarItem(p, cant, desc);
    }

    public void registrarPago(Factura f, MedioPago medio, double monto, String ref) {
        f.registrarPago(new Pago(UUID.randomUUID().toString(), monto, medio, ref));
    }

    public Factura emitir(Factura f) {
        inventario.descontar(f.getItems());
        f.cerrar();
        facturas.save(f);
        return f;
    }

    public void anular(String numero) {
        Factura f = facturas.findByNumero(numero);
        if (f == null) throw new IllegalArgumentException("Factura no existe");
        inventario.reponer(f.getItems());
        f.setEstado(EstadoFactura.ANULADA);
        facturas.save(f);
    }
}

