package servicio;

import dominio.Producto;

public class IVAEstandar implements PoliticaImpuesto {
    @Override
    public double calcular(Producto producto, int cantidad, double precioUnitario) {
        return producto.getTasaImpuesto() * (precioUnitario * cantidad);
    }
}
