package app;

import dominio.*;
import persistencia.ClienteRepository;
import persistencia.FacturaRepository;
import persistencia.ProductoRepository;
import persistencia.memory.*;
import servicio.*;


import java.time.LocalDate;
import java.util.UUID;

/**
 * Clase principal de la aplicación de ventas y facturación.
 * Demuestra creación de facturas, registro de pagos y reportes de ventas.
 */
public class Main {

    /** Imprime un título de sección en consola */
    private static void title(String t) {
        System.out.println("\n=== " + t + " ===");
    }

    /** Imprime los detalles de una factura */
    private static void printInvoice(Factura f) {
        System.out.println("- FACTURA");
        System.out.println("Número : " + f.getNumero());
        System.out.println("Cliente: " + (f.getCliente() == null ? "(contado)" : f.getCliente().getNombre()));
        System.out.println("Estado : " + f.getEstado());
        for (ItemFactura it : f.getItems()) {
            System.out.printf("  - %s x%d  (₡%.2f c/u, desc ₡%.2f)  ₡%.2f%n",
                    it.getProducto().getNombre(),
                    it.getCantidad(),
                    it.getPrecioUnitario(),
                    it.getDescuento(),
                    it.totalLinea());
        }
        System.out.printf("Subtotal   : ₡%.2f%n", f.getSubtotal());
        System.out.printf("Impuestos  : ₡%.2f%n", f.getTotalImpuestos());
        System.out.printf("Descuentos : ₡%.2f%n", f.getTotalDescuentos());
        System.out.printf("TOTAL      : ₡%.2f%n", f.getTotal());
        System.out.println("---------------------------------------");
    }

    public static void main(String[] args) {
        System.out.println("App started ✅");

        // --------------------- Repositorios en memoria ---------------------
        ProductoRepository prodRepo = new persistencia.memory.ProductoRepositoryImpl();
        ClienteRepository  cliRepo  = new persistencia.memory.ClienteRepositoryImpl();
        FacturaRepository  facRepo  = new persistencia.memory.FacturaRepositoryImpl();

        // --------------------- Servicios ---------------------
        InventarioService  inventario = new InventarioService(prodRepo);
        IVAEstandar        impuestos  = new IVAEstandar();
        FacturacionService facturas   = new FacturacionService(prodRepo, facRepo, cliRepo, impuestos, inventario);
        ReporteService     reportes   = new ReporteService(facRepo);

        // --------------------- Datos de ejemplo ---------------------
        prodRepo.save(new Producto("A1","Teclado",         25000, 0.13, 10, true));
        prodRepo.save(new Producto("B7","Mouse",           15000, 0.13, 20, true));
        prodRepo.save(new Producto("C3","Audífonos",       30000, 0.13,  5, true));
        prodRepo.save(new Producto("S1","Soporte técnico", 20000, 0.13,  0, false)); // servicio (no inventariable)

        cliRepo.save(new Cliente("C001","Ana Pérez",   "1-2345-6789","ana@correo.com","8888-8888"));
        cliRepo.save(new Cliente("C002","Carlos Ruiz", "2-1111-2222","carlos@correo.com","7777-7777"));

        // ================== Escenario 1: venta normal ==================
        title("Caso 1: venta con múltiples items");
        Factura f1 = facturas.iniciarFactura("C001");
        facturas.agregarItem(f1,"A1",2,0);
        facturas.agregarItem(f1,"B7",1,0);
        facturas.registrarPago(f1, MedioPago.EFECTIVO, 60000, "Caja 1");
        f1 = facturas.emitir(f1);
        printInvoice(f1);

        // ================== Escenario 2: venta contado con descuento ==================
        title("Caso 2: Venta con descuento");
        Factura f2 = facturas.iniciarFactura(null);
        facturas.agregarItem(f2,"C3",1,5000); // descuento
        facturas.registrarPago(f2, MedioPago.TARJETA, 25000, "POS-123");
        f2 = facturas.emitir(f2);
        printInvoice(f2);

        // ================== Escenario 3: varios pagos ==================
        title("Caso 3: Varios pagos (efectivo + tarjeta)");
        Factura f3 = facturas.iniciarFactura("C002");
        facturas.agregarItem(f3,"A1",1,0);
        facturas.agregarItem(f3,"B7",2,0);
        facturas.registrarPago(f3, MedioPago.EFECTIVO, 10000, "Caja 2");
        facturas.registrarPago(f3, MedioPago.TARJETA, 60000, "POS-456");
        f3 = facturas.emitir(f3);
        printInvoice(f3);

        // ================== Escenario 4: servicio ==================
        title("Caso 4: Servicio");
        Factura f4 = facturas.iniciarFactura("C001");
        facturas.agregarItem(f4,"S1",1,0); // servicio
        facturas.registrarPago(f4, MedioPago.TRANSFERENCIA, 20000, "TRX-001");
        f4 = facturas.emitir(f4);
        printInvoice(f4);

        // ================== Escenario 5: stock insuficiente ==================
        title("Caso 5: No hay stock suficiente");
        Factura f5 = facturas.iniciarFactura("C002");
        facturas.agregarItem(f5,"C3",99,0); // más de lo disponible
        try {
            f5 = facturas.emitir(f5); // esperado que falle
            printInvoice(f5);
        } catch (IllegalStateException ex) {
            System.out.println("No se procesó: " + ex.getMessage());
        }

        // ================== Escenario 6: anular factura ==================
        title("Caso 6: Anular factura");
        facturas.anular(f2.getNumero());
        System.out.println("Factura " + f2.getNumero() + " anulada.");

        // ================== Reporte del día ==================
        title("Ventas del día");
        double totalToday = reportes.ventasPorDia(LocalDate.now());
        System.out.printf("Ventas de hoy: ₡%.2f%n", totalToday);

        System.out.println("\nProceso finalizado ✅");
    }
}

